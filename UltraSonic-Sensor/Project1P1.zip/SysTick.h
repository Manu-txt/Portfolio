// SysTick.h
// Runs on LM4F120/TM4C123
/*
``Class: CECS 347 Embedded Systems 2
``Group 5
Project 1
Filename: Systick.h
Objective: provide functions that initialize the systick module
Professor: Min He
01/29/2025
 */
// Initialize SysTick with interrupt enabled and running at bus clock.
void SysTick_Init(void);
// Start periodic interrupts with given period (in bus clock cycles)
void SysTick_Start(unsigned long period);
// Stop SysTick interrupts
void SysTick_Stop(void);
// Global flag to indicate when 250ms has passed
extern volatile unsigned long Tick_Flag;